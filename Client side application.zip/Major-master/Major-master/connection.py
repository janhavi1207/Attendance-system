# from pymongo import MongoClient
# class MongoConnection:
#     def getConnection():
#         try:
#             connection = MongoClient("mongodb://localhost:27017/")
#             print("Connected Successfully")
#             db=connection.users_database
#             collection = db.ImageDB
#             return collection
#         except:   
#             print("Could not connect to MongoDB")


from pymongo import MongoClient
# Connect to MongoDB
client = MongoClient('mongodb://localhost:27017/')

# Access a specific database
db = client['mydatabase']

# Access a specific collection within the database
collection = db['mycollection']

# Insert a document into the collection
document = {"name": "John", "age": 30}
collection.insert_one(document)

# Find documents in the collection
result = collection.find_one({"name": "John"})
print(result)

# Update a document in the collection
collection.update_one({"name": "John"}, {"$set": {"age": 35}})

# Delete a document from the collection
collection.delete_one({"name": "John"})

# Close the connection to MongoDB
client.close()