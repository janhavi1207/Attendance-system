# -*- coding: utf-8 -*-
"""
Created on Wed Feb 27 12:41:58 2019

@author: Trevor
"""

back = str(input("Enter the Path\t"))
bck = "\\"
frd = "/"
print(back.replace(bck,frd))
